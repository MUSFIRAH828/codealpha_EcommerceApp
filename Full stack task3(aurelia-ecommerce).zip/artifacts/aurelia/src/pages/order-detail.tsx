import { Link } from "wouter";
import { useGetOrder, getGetOrderQueryKey } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Clock, Package, Truck, XCircle, ChevronLeft } from "lucide-react";

const statusSteps = ["pending", "processing", "shipped", "delivered"];
const statusIcons: Record<string, React.ReactNode> = {
  pending: <Clock className="w-5 h-5" />,
  processing: <Package className="w-5 h-5" />,
  shipped: <Truck className="w-5 h-5" />,
  delivered: <CheckCircle2 className="w-5 h-5" />,
  cancelled: <XCircle className="w-5 h-5" />,
};

export default function OrderDetail({ params }: { params: { id: string } }) {
  const { data: order, isLoading } = useGetOrder(params.id, { query: { queryKey: getGetOrderQueryKey(params.id) } });

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Skeleton className="h-6 w-32 mb-8" />
        <Skeleton className="h-10 w-64 mb-6" />
        <Skeleton className="h-32 w-full mb-6" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center">
        <h2 className="text-xl font-serif mb-4">Order not found</h2>
        <Link href="/orders"><Button variant="outline" className="rounded-none">Back to Orders</Button></Link>
      </div>
    );
  }

  const currentStepIdx = order.status === "cancelled" ? -1 : statusSteps.indexOf(order.status);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <Link href="/orders" className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors mb-8">
        <ChevronLeft className="w-3 h-3" /> Back to Orders
      </Link>

      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-10">
        <div>
          <h1 className="text-3xl font-serif font-bold uppercase tracking-wider mb-2">Order Details</h1>
          <p className="text-sm text-muted-foreground">#{order.id.slice(-8).toUpperCase()} · {new Date(order.createdAt).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}</p>
        </div>
        <div className={`flex items-center gap-2 px-4 py-2 text-sm font-medium uppercase tracking-wider ${order.status === "delivered" ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" : order.status === "cancelled" ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400" : "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400"}`}>
          {statusIcons[order.status]} {order.status}
        </div>
      </div>

      {/* Status Timeline */}
      {order.status !== "cancelled" && (
        <div className="mb-10 p-6 border border-border">
          <h2 className="text-xs uppercase tracking-widest text-muted-foreground mb-6">Order Progress</h2>
          <div className="flex items-center">
            {statusSteps.map((step, idx) => (
              <div key={step} className="flex items-center flex-1 last:flex-none">
                <div className={`flex flex-col items-center gap-2 ${idx <= currentStepIdx ? "text-primary" : "text-muted-foreground"}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${idx <= currentStepIdx ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background"}`}>
                    {idx <= currentStepIdx ? <CheckCircle2 className="w-4 h-4" /> : <span className="text-xs">{idx + 1}</span>}
                  </div>
                  <span className="text-xs uppercase tracking-wider">{step}</span>
                </div>
                {idx < statusSteps.length - 1 && (
                  <div className={`flex-1 h-0.5 mx-2 mb-5 ${idx < currentStepIdx ? "bg-primary" : "bg-border"}`} />
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <h2 className="text-sm font-medium uppercase tracking-widest mb-4 pb-2 border-b border-border">Items</h2>
          <div className="divide-y divide-border">
            {order.items.map((item, idx) => (
              <div key={idx} className="flex gap-4 py-4">
                <img src={item.image || "https://via.placeholder.com/80"} alt={item.name} className="w-20 h-26 object-cover bg-muted" style={{ height: "104px" }} />
                <div className="flex-1">
                  <p className="font-medium">{item.name}</p>
                  <p className="text-sm text-muted-foreground mt-1">Qty: {item.quantity}</p>
                  <p className="text-sm mt-1">{formatCurrency(item.price)} each</p>
                </div>
                <div className="font-medium">{formatCurrency(item.price * item.quantity)}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-border flex justify-between font-medium text-lg">
            <span>Total</span><span>{formatCurrency(order.total)}</span>
          </div>
        </div>

        <div className="space-y-6">
          <div className="p-6 bg-secondary/30 border border-border/50">
            <h2 className="text-xs uppercase tracking-widest text-muted-foreground mb-4">Shipping Address</h2>
            <div className="text-sm space-y-1">
              <p className="font-medium">{order.shippingAddress.fullName}</p>
              <p>{order.shippingAddress.address}</p>
              <p>{order.shippingAddress.city}, {order.shippingAddress.postalCode}</p>
              <p>{order.shippingAddress.country}</p>
              {order.shippingAddress.phone && <p className="text-muted-foreground">{order.shippingAddress.phone}</p>}
            </div>
          </div>
          <div className="p-6 bg-secondary/30 border border-border/50">
            <h2 className="text-xs uppercase tracking-widest text-muted-foreground mb-4">Payment</h2>
            <p className="text-sm capitalize">{order.paymentMethod}</p>
            <p className={`text-sm mt-1 ${order.isPaid ? "text-green-600" : "text-muted-foreground"}`}>{order.isPaid ? "Paid" : "Pending payment"}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
