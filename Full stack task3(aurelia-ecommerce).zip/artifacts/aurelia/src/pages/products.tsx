import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useListProducts, useListCategories } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Search, Filter, SlidersHorizontal } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

export default function Products() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const initialCategory = searchParams.get('category') || undefined;

  const [q, setQ] = useState("");
  const [category, setCategory] = useState<string | undefined>(initialCategory);
  const [sort, setSort] = useState<any>("newest");
  
  // Update category when URL changes
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const cat = params.get('category');
    if (cat) setCategory(cat);
  }, [location]);

  const { data: categoryData } = useListCategories();
  const { data: productData, isLoading } = useListProducts({
    q: q || undefined,
    category: category && category !== 'all' ? category : undefined,
    sort,
    limit: 20
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-6">
        <div>
          <h1 className="text-3xl font-serif font-bold uppercase tracking-wider mb-2">
            {category && category !== 'all' ? category : 'The Collection'}
          </h1>
          <p className="text-muted-foreground">
            {productData?.total || 0} {productData?.total === 1 ? 'result' : 'results'}
          </p>
        </div>
        
        <div className="w-full md:w-auto flex flex-col sm:flex-row gap-4">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search pieces..." 
              value={q}
              onChange={(e) => setQ(e.target.value)}
              className="pl-10 rounded-none border-border"
            />
          </div>
          
          <div className="flex gap-4 w-full sm:w-auto">
            <Select value={category || "all"} onValueChange={(v) => setCategory(v)}>
              <SelectTrigger className="w-full sm:w-[160px] rounded-none border-border">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categoryData?.map(c => (
                  <SelectItem key={c.name} value={c.name}>{c.name} ({c.count})</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sort} onValueChange={setSort}>
              <SelectTrigger className="w-full sm:w-[160px] rounded-none border-border">
                <SlidersHorizontal className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest Arrivals</SelectItem>
                <SelectItem value="price_asc">Price: Low to High</SelectItem>
                <SelectItem value="price_desc">Price: High to Low</SelectItem>
                <SelectItem value="rating">Top Rated</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="h-px w-full bg-border mb-8" />

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <div key={i} className="space-y-4">
              <Skeleton className="aspect-[3/4] w-full" />
              <Skeleton className="h-5 w-2/3" />
              <Skeleton className="h-5 w-1/3" />
            </div>
          ))}
        </div>
      ) : productData?.products.length === 0 ? (
        <div className="text-center py-24 bg-secondary/30">
          <p className="text-xl font-serif text-muted-foreground mb-4">No pieces found matching your criteria.</p>
          <Button variant="outline" className="rounded-none" onClick={() => { setQ(""); setCategory("all"); }}>
            Clear Filters
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12">
          {productData?.products.map((product) => (
            <Link key={product.id} href={`/products/${product.id}`} className="group cursor-pointer">
              <div className="aspect-[3/4] relative overflow-hidden mb-4 bg-muted">
                <img 
                  src={product.images?.[0] || 'https://via.placeholder.com/400x500'} 
                  alt={product.name}
                  className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105"
                />
                {product.comparePrice && product.comparePrice > product.price && (
                  <div className="absolute top-4 right-4 bg-background/90 backdrop-blur-sm text-foreground text-xs px-2 py-1 tracking-widest uppercase">
                    Sale
                  </div>
                )}
              </div>
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground uppercase tracking-wider">{product.category}</p>
                <h3 className="font-medium text-foreground group-hover:text-primary transition-colors line-clamp-1">{product.name}</h3>
                <div className="flex items-center space-x-2">
                  <p className="text-sm font-medium">{formatCurrency(product.price)}</p>
                  {product.comparePrice && (
                    <p className="text-sm text-muted-foreground line-through">{formatCurrency(product.comparePrice)}</p>
                  )}
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
