import { Link } from "wouter";
import { useGetFeaturedProducts } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { data: featuredProducts, isLoading } = useGetFeaturedProducts();

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden bg-muted">
        <div className="absolute inset-0 bg-black/40 z-10" />
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=2070&auto=format&fit=crop")' }}
        />
        <div className="relative z-20 text-center text-white px-4">
          <h1 className="text-5xl md:text-7xl font-serif font-bold tracking-tight mb-6 uppercase">
            Aurelia
          </h1>
          <p className="text-lg md:text-xl font-light tracking-wide max-w-2xl mx-auto mb-8 text-white/90">
            Discover the new collection of curated luxury pieces for the modern individual.
          </p>
          <Link href="/products" className="inline-block bg-primary text-primary-foreground px-8 py-4 text-sm font-medium tracking-widest uppercase hover:bg-primary/90 transition-colors">
            Shop the Collection
          </Link>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-serif font-bold mb-4 uppercase tracking-wider">Featured Curations</h2>
          <div className="h-px w-16 bg-primary mx-auto" />
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="aspect-[3/4] w-full" />
                <Skeleton className="h-5 w-2/3" />
                <Skeleton className="h-5 w-1/3" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-10">
            {featuredProducts?.map((product) => (
              <Link key={product.id} href={`/products/${product.id}`} className="group cursor-pointer">
                <div className="aspect-[3/4] relative overflow-hidden mb-4 bg-muted">
                  <img 
                    src={product.images?.[0] || 'https://images.unsplash.com/photo-1591561954557-26941169b49e?q=80&w=987&auto=format&fit=crop'} 
                    alt={product.name}
                    className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105"
                  />
                  {product.comparePrice && product.comparePrice > product.price && (
                    <div className="absolute top-4 right-4 bg-background/90 backdrop-blur-sm text-foreground text-xs px-2 py-1 tracking-widest uppercase">
                      Sale
                    </div>
                  )}
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">{product.category}</p>
                  <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">{product.name}</h3>
                  <div className="flex items-center space-x-2">
                    <p className="text-sm font-medium">{formatCurrency(product.price)}</p>
                    {product.comparePrice && (
                      <p className="text-sm text-muted-foreground line-through">{formatCurrency(product.comparePrice)}</p>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* Brand Story */}
      <section className="bg-secondary py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div className="order-2 md:order-1 space-y-6">
              <h2 className="text-3xl font-serif font-bold uppercase tracking-wider">The Aurelia Standard</h2>
              <div className="h-px w-16 bg-primary" />
              <p className="text-muted-foreground leading-relaxed">
                We believe that true luxury is found in the details. Every piece in our collection is thoughtfully selected for its exceptional quality, timeless design, and impeccable craftsmanship. 
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Aurelia is more than a destination—it is a curation of the finest elements of a well-lived life, designed for those who appreciate quiet elegance.
              </p>
              <div className="pt-4">
                <Link href="/about" className="text-sm font-medium tracking-widest uppercase border-b border-primary pb-1 hover:text-primary transition-colors">
                  Discover Our Story
                </Link>
              </div>
            </div>
            <div className="order-1 md:order-2 aspect-square md:aspect-[4/5] bg-muted relative overflow-hidden">
               <img 
                  src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=2070&auto=format&fit=crop" 
                  alt="Brand Story"
                  className="object-cover w-full h-full"
                />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
