import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useGetProduct, useCreateProduct, useUpdateProduct, getListProductsQueryKey, getGetProductQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { ChevronLeft, Save } from "lucide-react";

const productSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  price: z.coerce.number().positive("Price must be positive"),
  comparePrice: z.coerce.number().positive().optional().or(z.literal("")),
  category: z.string().min(1, "Category is required"),
  stock: z.coerce.number().min(0, "Stock cannot be negative"),
  images: z.string().optional(),
  featured: z.boolean().default(false),
  tags: z.string().optional(),
});

type ProductFormValues = z.infer<typeof productSchema>;

export default function AdminProductForm({ params }: { params?: { id?: string } }) {
  const productId = params?.id;
  const isEditing = !!productId;
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: existingProduct, isLoading: isLoadingProduct } = useGetProduct(productId || "", {
    query: { enabled: isEditing, queryKey: getGetProductQueryKey(productId || "") },
  });

  const createMutation = useCreateProduct();
  const updateMutation = useUpdateProduct();
  const isPending = createMutation.isPending || updateMutation.isPending;

  const form = useForm<ProductFormValues>({
    resolver: zodResolver(productSchema),
    defaultValues: { name: "", description: "", price: 0, comparePrice: "", category: "", stock: 0, images: "", featured: false, tags: "" },
  });

  useEffect(() => {
    if (existingProduct) {
      form.reset({
        name: existingProduct.name,
        description: existingProduct.description,
        price: existingProduct.price,
        comparePrice: existingProduct.comparePrice || "",
        category: existingProduct.category,
        stock: existingProduct.stock,
        images: existingProduct.images?.join(", ") || "",
        featured: existingProduct.featured || false,
        tags: existingProduct.tags?.join(", ") || "",
      });
    }
  }, [existingProduct, form]);

  const onSubmit = (values: ProductFormValues) => {
    const images = values.images ? values.images.split(",").map(s => s.trim()).filter(Boolean) : [];
    const tags = values.tags ? values.tags.split(",").map(s => s.trim()).filter(Boolean) : [];
    const comparePrice = values.comparePrice !== "" ? Number(values.comparePrice) : null;

    const productData = { name: values.name, description: values.description, price: values.price, comparePrice, category: values.category, stock: values.stock, images, featured: values.featured, tags };

    if (isEditing && productId) {
      updateMutation.mutate(
        { id: productId, data: productData },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
            queryClient.invalidateQueries({ queryKey: getGetProductQueryKey(productId) });
            toast({ title: "Product updated successfully" });
            setLocation("/admin/products");
          },
          onError: () => toast({ title: "Failed to update product", variant: "destructive" }),
        }
      );
    } else {
      createMutation.mutate(
        { data: productData },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
            toast({ title: "Product created successfully" });
            setLocation("/admin/products");
          },
          onError: () => toast({ title: "Failed to create product", variant: "destructive" }),
        }
      );
    }
  };

  if (isEditing && isLoadingProduct) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Skeleton className="h-6 w-32 mb-8" /><Skeleton className="h-10 w-64 mb-8" />
        <div className="space-y-6">{[1,2,3,4,5].map(i => <Skeleton key={i} className="h-16 w-full" />)}</div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <Link href="/admin/products" className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors mb-8">
        <ChevronLeft className="w-3 h-3" /> Back to Products
      </Link>
      <h1 className="text-3xl font-serif font-bold uppercase tracking-wider mb-10">{isEditing ? "Edit Product" : "Add New Product"}</h1>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField control={form.control} name="name" render={({ field }) => (
            <FormItem>
              <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Product Name *</FormLabel>
              <FormControl><Input {...field} className="rounded-none" /></FormControl>
              <FormMessage />
            </FormItem>
          )} />

          <FormField control={form.control} name="description" render={({ field }) => (
            <FormItem>
              <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Description *</FormLabel>
              <FormControl><Textarea {...field} rows={4} className="rounded-none resize-none" /></FormControl>
              <FormMessage />
            </FormItem>
          )} />

          <div className="grid grid-cols-2 gap-6">
            <FormField control={form.control} name="price" render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Price (USD) *</FormLabel>
                <FormControl><Input {...field} type="number" step="0.01" className="rounded-none" /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="comparePrice" render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Compare Price</FormLabel>
                <FormControl><Input {...field} type="number" step="0.01" className="rounded-none" /></FormControl>
                <FormDescription className="text-xs">Original price before discount</FormDescription>
                <FormMessage />
              </FormItem>
            )} />
          </div>

          <div className="grid grid-cols-2 gap-6">
            <FormField control={form.control} name="category" render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Category *</FormLabel>
                <FormControl><Input {...field} className="rounded-none" placeholder="e.g. Handbags, Shoes..." /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="stock" render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Stock *</FormLabel>
                <FormControl><Input {...field} type="number" className="rounded-none" /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
          </div>

          <FormField control={form.control} name="images" render={({ field }) => (
            <FormItem>
              <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Image URLs</FormLabel>
              <FormControl><Textarea {...field} rows={2} className="rounded-none resize-none" placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg" /></FormControl>
              <FormDescription className="text-xs">Comma-separated image URLs</FormDescription>
              <FormMessage />
            </FormItem>
          )} />

          <FormField control={form.control} name="tags" render={({ field }) => (
            <FormItem>
              <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Tags</FormLabel>
              <FormControl><Input {...field} className="rounded-none" placeholder="luxury, leather, handmade..." /></FormControl>
              <FormDescription className="text-xs">Comma-separated tags</FormDescription>
              <FormMessage />
            </FormItem>
          )} />

          <FormField control={form.control} name="featured" render={({ field }) => (
            <FormItem className="flex items-center justify-between p-4 border border-border">
              <div>
                <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Featured Product</FormLabel>
                <FormDescription className="text-xs mt-1">Featured products appear on the homepage</FormDescription>
              </div>
              <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl>
            </FormItem>
          )} />

          <div className="flex gap-4 pt-4">
            <Button type="submit" disabled={isPending} className="rounded-none tracking-widest uppercase px-8">
              <Save className="w-4 h-4 mr-2" />{isPending ? "Saving..." : isEditing ? "Update Product" : "Create Product"}
            </Button>
            <Link href="/admin/products"><Button type="button" variant="outline" className="rounded-none tracking-widest uppercase">Cancel</Button></Link>
          </div>
        </form>
      </Form>
    </div>
  );
}
