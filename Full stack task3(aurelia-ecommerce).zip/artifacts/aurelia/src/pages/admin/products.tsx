import { useState } from "react";
import { Link } from "wouter";
import { useListProducts, useDeleteProduct, getListProductsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, AlertTriangle } from "lucide-react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function AdminProducts() {
  const { data: productsData, isLoading } = useListProducts({ limit: 50 });
  const deleteProductMutation = useDeleteProduct();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const handleDelete = () => {
    if (!deleteId) return;
    deleteProductMutation.mutate(
      { id: deleteId },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
          toast({ title: "Product deleted" });
          setDeleteId(null);
        },
        onError: () => {
          toast({ title: "Failed to delete product", variant: "destructive" });
          setDeleteId(null);
        },
      }
    );
  };

  const products = productsData?.products || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center justify-between mb-10">
        <div>
          <h1 className="text-3xl font-serif font-bold uppercase tracking-wider">Products</h1>
          <p className="text-sm text-muted-foreground mt-1">{productsData?.total || 0} total products</p>
        </div>
        <div className="flex gap-4">
          <Link href="/admin"><Button variant="outline" className="rounded-none text-xs uppercase tracking-widest">Dashboard</Button></Link>
          <Link href="/admin/products/new"><Button className="rounded-none text-xs uppercase tracking-widest"><Plus className="w-4 h-4 mr-2" />Add Product</Button></Link>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-3">{[1,2,3,4,5].map(i => <Skeleton key={i} className="h-20 w-full" />)}</div>
      ) : products.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 border border-dashed border-border">
          <p className="text-muted-foreground mb-4">No products yet</p>
          <Link href="/admin/products/new"><Button className="rounded-none text-xs uppercase tracking-widest"><Plus className="w-4 h-4 mr-2" />Add First Product</Button></Link>
        </div>
      ) : (
        <div className="border border-border overflow-hidden">
          <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-3 bg-muted/50 text-xs uppercase tracking-widest text-muted-foreground border-b border-border">
            <div className="col-span-1">Image</div>
            <div className="col-span-4">Name</div>
            <div className="col-span-2">Category</div>
            <div className="col-span-2">Price</div>
            <div className="col-span-1">Stock</div>
            <div className="col-span-2 text-right">Actions</div>
          </div>
          <div className="divide-y divide-border">
            {products.map((product) => (
              <div key={product.id} className="grid grid-cols-12 gap-4 px-6 py-4 items-center hover:bg-muted/20 transition-colors">
                <div className="col-span-1">
                  <img src={product.images?.[0] || "https://via.placeholder.com/48"} alt={product.name} className="w-12 h-14 object-cover bg-muted" />
                </div>
                <div className="col-span-4">
                  <p className="font-medium text-sm line-clamp-1">{product.name}</p>
                  {product.featured && <span className="text-xs text-primary uppercase tracking-wider">Featured</span>}
                </div>
                <div className="col-span-2 text-sm text-muted-foreground capitalize">{product.category}</div>
                <div className="col-span-2 text-sm">
                  <span className="font-medium">{formatCurrency(product.price)}</span>
                  {product.comparePrice && product.comparePrice > product.price && (
                    <span className="ml-2 text-xs text-muted-foreground line-through">{formatCurrency(product.comparePrice)}</span>
                  )}
                </div>
                <div className="col-span-1 text-sm">
                  <span className={product.stock === 0 ? "text-destructive" : product.stock < 5 ? "text-yellow-600" : ""}>{product.stock}</span>
                </div>
                <div className="col-span-2 flex justify-end gap-2">
                  <Link href={`/admin/products/${product.id}/edit`}>
                    <Button variant="outline" size="sm" className="rounded-none h-8 w-8 p-0"><Pencil className="w-3 h-3" /></Button>
                  </Link>
                  <Button variant="outline" size="sm" className="rounded-none h-8 w-8 p-0 hover:border-destructive hover:text-destructive" onClick={() => setDeleteId(product.id)}>
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="rounded-none">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-destructive" />Delete Product</AlertDialogTitle>
            <AlertDialogDescription>This action cannot be undone. The product will be permanently removed.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-none">Cancel</AlertDialogCancel>
            <AlertDialogAction className="rounded-none bg-destructive hover:bg-destructive/90" onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
