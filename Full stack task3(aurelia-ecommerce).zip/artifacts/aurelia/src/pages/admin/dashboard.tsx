import { Link } from "wouter";
import { useGetDashboardStats } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { TrendingUp, ShoppingBag, Package, Users, ChevronRight } from "lucide-react";

const statusColors: Record<string, string> = {
  pending: "#eab308", processing: "#3b82f6", shipped: "#a855f7", delivered: "#22c55e", cancelled: "#ef4444",
};

const PIE_COLORS = ["#eab308", "#3b82f6", "#a855f7", "#22c55e", "#ef4444"];

export default function AdminDashboard() {
  const { data: stats, isLoading } = useGetDashboardStats();

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Skeleton className="h-10 w-64 mb-8" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-32 w-full" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Skeleton className="h-80 w-full" /><Skeleton className="h-80 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center justify-between mb-10">
        <h1 className="text-3xl font-serif font-bold uppercase tracking-wider">Dashboard</h1>
        <div className="flex gap-4 text-xs uppercase tracking-widest">
          <Link href="/admin/products" className="text-muted-foreground hover:text-foreground transition-colors">Products</Link>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        {[
          { label: "Total Revenue", value: formatCurrency(stats?.totalRevenue || 0), icon: TrendingUp, change: "+12% this month" },
          { label: "Total Orders", value: String(stats?.totalOrders || 0), icon: ShoppingBag, change: `${stats?.recentOrders?.length || 0} recent` },
          { label: "Products", value: String(stats?.totalProducts || 0), icon: Package, change: "in catalog" },
          { label: "Customers", value: String(stats?.totalUsers || 0), icon: Users, change: "registered" },
        ].map((stat) => (
          <div key={stat.label} className="p-6 border border-border bg-card">
            <div className="flex items-start justify-between mb-4">
              <span className="text-xs uppercase tracking-widest text-muted-foreground">{stat.label}</span>
              <stat.icon className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="text-2xl font-medium mb-1">{stat.value}</div>
            <div className="text-xs text-muted-foreground">{stat.change}</div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
        <div className="lg:col-span-2 border border-border p-6">
          <h2 className="text-xs uppercase tracking-widest text-muted-foreground mb-6">Revenue by Month</h2>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={stats?.revenueByMonth || []} barSize={24}>
              <XAxis dataKey="month" tick={{ fontSize: 10 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 10 }} tickLine={false} axisLine={false} tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
              <Tooltip formatter={(v: number) => formatCurrency(v)} contentStyle={{ border: "1px solid hsl(var(--border))", borderRadius: 0, fontSize: 12 }} />
              <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={0} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-border p-6">
          <h2 className="text-xs uppercase tracking-widest text-muted-foreground mb-6">Orders by Status</h2>
          {stats?.ordersByStatus && stats.ordersByStatus.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={stats.ordersByStatus} dataKey="count" nameKey="status" cx="50%" cy="50%" outerRadius={70}>
                    {stats.ordersByStatus.map((entry, index) => (
                      <Cell key={entry.status} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v: number, name: string) => [v, name]} contentStyle={{ border: "1px solid hsl(var(--border))", borderRadius: 0, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-2 mt-4">
                {stats.ordersByStatus.map((entry, idx) => (
                  <div key={entry.status} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: PIE_COLORS[idx % PIE_COLORS.length] }} />
                      <span className="capitalize text-xs">{entry.status}</span>
                    </div>
                    <span className="font-medium">{entry.count}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-48 text-muted-foreground text-sm">No order data yet</div>
          )}
        </div>
      </div>

      {/* Recent Orders + Top Products */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="border border-border">
          <div className="flex items-center justify-between p-6 border-b border-border">
            <h2 className="text-xs uppercase tracking-widest text-muted-foreground">Recent Orders</h2>
          </div>
          <div className="divide-y divide-border">
            {stats?.recentOrders?.slice(0, 6).map((order) => (
              <div key={order.id} className="flex items-center justify-between px-6 py-4 hover:bg-muted/30 transition-colors">
                <div>
                  <p className="text-sm font-mono">#{order.id.slice(-6).toUpperCase()}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {new Date(order.createdAt).toLocaleDateString()} · {order.items.length} items
                  </p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm font-medium">{formatCurrency(order.total)}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full capitalize ${statusColors[order.status] ? "text-white" : ""}`} style={{ backgroundColor: statusColors[order.status] + "33", color: statusColors[order.status] }}>
                    {order.status}
                  </span>
                </div>
              </div>
            ))}
            {(!stats?.recentOrders || stats.recentOrders.length === 0) && (
              <div className="p-8 text-center text-muted-foreground text-sm">No orders yet</div>
            )}
          </div>
        </div>

        <div className="border border-border">
          <div className="flex items-center justify-between p-6 border-b border-border">
            <h2 className="text-xs uppercase tracking-widest text-muted-foreground">Top Products</h2>
            <Link href="/admin/products" className="text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors">
              View all <ChevronRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-border">
            {stats?.topProducts?.map((product) => (
              <div key={product.id} className="flex items-center gap-4 px-6 py-4 hover:bg-muted/30 transition-colors">
                <img src={product.images?.[0] || "https://via.placeholder.com/48"} alt={product.name} className="w-12 h-14 object-cover bg-muted shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{product.name}</p>
                  <p className="text-xs text-muted-foreground">{product.category}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-medium">{formatCurrency(product.price)}</p>
                  <p className="text-xs text-muted-foreground">Stock: {product.stock}</p>
                </div>
              </div>
            ))}
            {(!stats?.topProducts || stats.topProducts.length === 0) && (
              <div className="p-8 text-center text-muted-foreground text-sm">No products yet</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
