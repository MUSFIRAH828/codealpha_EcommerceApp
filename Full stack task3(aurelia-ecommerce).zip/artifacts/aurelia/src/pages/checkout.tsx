import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useGetCart, useCreateOrder, getGetCartQueryKey, getListOrdersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { CreditCard, Lock, ChevronRight } from "lucide-react";

const checkoutSchema = z.object({
  fullName: z.string().min(2, "Full name is required"),
  address: z.string().min(5, "Address is required"),
  city: z.string().min(2, "City is required"),
  postalCode: z.string().min(3, "Postal code is required"),
  country: z.string().min(2, "Country is required"),
  phone: z.string().optional(),
  paymentMethod: z.string().default("card"),
});

type CheckoutFormValues = z.infer<typeof checkoutSchema>;

export default function Checkout() {
  const { data: cart, isLoading } = useGetCart();
  const createOrderMutation = useCreateOrder();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [paymentMethod, setPaymentMethod] = useState("card");

  const form = useForm<CheckoutFormValues>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: { fullName: "", address: "", city: "", postalCode: "", country: "", phone: "", paymentMethod: "card" },
  });

  const onSubmit = async (values: CheckoutFormValues) => {
    createOrderMutation.mutate(
      { data: { shippingAddress: { fullName: values.fullName, address: values.address, city: values.city, postalCode: values.postalCode, country: values.country, phone: values.phone || null }, paymentMethod } },
      {
        onSuccess: (order) => {
          queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });
          toast({ title: "Order placed successfully", description: "Thank you for your purchase." });
          setLocation(`/orders/${order.id}`);
        },
        onError: () => {
          toast({ title: "Failed to place order", description: "Please try again.", variant: "destructive" });
        },
      }
    );
  };

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Skeleton className="h-10 w-48 mb-8" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div className="space-y-4">{[1,2,3,4].map(i => <Skeleton key={i} className="h-14 w-full" />)}</div>
          <div><Skeleton className="h-80 w-full" /></div>
        </div>
      </div>
    );
  }

  const shippingCost = cart && cart.total >= 500 ? 0 : 25;
  const orderTotal = cart ? cart.total + shippingCost : 0;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <nav className="flex items-center gap-2 text-xs text-muted-foreground uppercase tracking-widest mb-10">
        <span>Cart</span><ChevronRight className="w-3 h-3" /><span className="text-foreground">Checkout</span>
      </nav>
      <h1 className="text-3xl font-serif font-bold uppercase tracking-wider mb-10">Checkout</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        <div>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div>
                <h2 className="text-sm font-medium uppercase tracking-widest mb-6 pb-2 border-b border-border">Shipping Address</h2>
                <div className="space-y-4">
                  <FormField control={form.control} name="fullName" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Full Name</FormLabel>
                      <FormControl><Input {...field} className="rounded-none border-border focus:border-primary" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="address" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Address</FormLabel>
                      <FormControl><Input {...field} className="rounded-none border-border focus:border-primary" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField control={form.control} name="city" render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">City</FormLabel>
                        <FormControl><Input {...field} className="rounded-none" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="postalCode" render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Postal Code</FormLabel>
                        <FormControl><Input {...field} className="rounded-none" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>
                  <FormField control={form.control} name="country" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Country</FormLabel>
                      <FormControl><Input {...field} className="rounded-none" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="phone" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Phone (optional)</FormLabel>
                      <FormControl><Input {...field} className="rounded-none" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
              </div>

              <div>
                <h2 className="text-sm font-medium uppercase tracking-widest mb-6 pb-2 border-b border-border">Payment Method</h2>
                <div className="space-y-3">
                  {[{ id: "card", label: "Credit / Debit Card" }, { id: "paypal", label: "PayPal" }, { id: "bank", label: "Bank Transfer" }].map((method) => (
                    <button key={method.id} type="button" onClick={() => setPaymentMethod(method.id)}
                      className={`w-full flex items-center gap-4 p-4 border transition-colors text-left ${paymentMethod === method.id ? "border-primary bg-primary/5" : "border-border hover:border-muted-foreground"}`}>
                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${paymentMethod === method.id ? "border-primary" : "border-muted-foreground"}`}>
                        {paymentMethod === method.id && <div className="w-2 h-2 rounded-full bg-primary" />}
                      </div>
                      <CreditCard className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">{method.label}</span>
                    </button>
                  ))}
                </div>
                {paymentMethod === "card" && (
                  <div className="mt-4 p-4 bg-muted/30 border border-border text-xs text-muted-foreground flex items-center gap-2">
                    <Lock className="w-3 h-3" /> This is a demo checkout — no real payment is processed.
                  </div>
                )}
              </div>

              <Button type="submit" disabled={createOrderMutation.isPending} className="w-full py-6 rounded-none tracking-widest uppercase text-sm mt-4">
                {createOrderMutation.isPending ? "Placing Order..." : `Place Order — ${formatCurrency(orderTotal)}`}
              </Button>
            </form>
          </Form>
        </div>

        <div>
          <div className="bg-secondary/30 border border-border/50 p-8 sticky top-24">
            <h2 className="text-sm font-medium uppercase tracking-widest mb-6">Order Summary</h2>
            <div className="space-y-4 mb-6">
              {cart?.items.map((item) => (
                <div key={item.product.id} className="flex gap-4">
                  <div className="relative">
                    <img src={item.product.images?.[0] || "https://via.placeholder.com/80"} alt={item.product.name} className="w-16 h-20 object-cover bg-muted" />
                    <span className="absolute -top-2 -right-2 w-5 h-5 bg-foreground text-background text-xs rounded-full flex items-center justify-center">{item.quantity}</span>
                  </div>
                  <div className="flex-1 flex flex-col justify-center">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider">{item.product.category}</p>
                    <p className="text-sm font-medium line-clamp-1">{item.product.name}</p>
                    <p className="text-sm mt-1">{formatCurrency(item.price * item.quantity)}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="h-px bg-border mb-4" />
            <div className="space-y-2 text-sm mb-4">
              <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{formatCurrency(cart?.total || 0)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span>{shippingCost === 0 ? "Complimentary" : formatCurrency(shippingCost)}</span></div>
            </div>
            <div className="h-px bg-border mb-4" />
            <div className="flex justify-between font-medium text-base"><span>Total</span><span>{formatCurrency(orderTotal)}</span></div>
            <p className="text-xs text-muted-foreground mt-4">Complimentary shipping on orders over {formatCurrency(500)}.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
