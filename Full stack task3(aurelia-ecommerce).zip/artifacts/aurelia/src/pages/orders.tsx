import { Link } from "wouter";
import { useListOrders } from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Package, ChevronRight } from "lucide-react";

const statusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  processing: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  shipped: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
  delivered: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  cancelled: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

export default function Orders() {
  const { data: orders, isLoading } = useListOrders();

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Skeleton className="h-10 w-48 mb-8" />
        <div className="space-y-4">{[1,2,3].map(i => <Skeleton key={i} className="h-32 w-full" />)}</div>
      </div>
    );
  }

  if (!orders || orders.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
        <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center mb-6">
          <Package className="w-8 h-8 text-muted-foreground" />
        </div>
        <h2 className="text-2xl font-serif mb-4 uppercase tracking-wider">No orders yet</h2>
        <p className="text-muted-foreground mb-8 max-w-md">Your order history will appear here once you make your first purchase.</p>
        <Link href="/products">
          <Button className="rounded-none tracking-widest uppercase px-8">Shop the Collection</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-serif font-bold uppercase tracking-wider mb-10">My Orders</h1>
      <div className="space-y-4">
        {orders.map((order) => (
          <Link key={order.id} href={`/orders/${order.id}`}>
            <div className="border border-border hover:border-primary/40 transition-colors p-6 cursor-pointer group">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-3">
                    <span className="text-xs uppercase tracking-widest text-muted-foreground">Order</span>
                    <span className="font-mono text-sm">#{order.id.slice(-8).toUpperCase()}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full uppercase tracking-wider font-medium ${statusColors[order.status] || ""}`}>
                      {order.status}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {new Date(order.createdAt).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
                    {" · "}{order.items.length} item{order.items.length !== 1 ? "s" : ""}
                  </p>
                </div>
                <div className="flex items-center gap-6">
                  <span className="text-lg font-medium">{formatCurrency(order.total)}</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
              </div>
              <div className="mt-4 flex gap-3 overflow-x-auto pb-1">
                {order.items.slice(0, 4).map((item, idx) => (
                  <div key={idx} className="shrink-0 w-14 h-18 bg-muted">
                    <img src={item.image || "https://via.placeholder.com/56x72"} alt={item.name} className="w-14 h-18 object-cover" style={{ height: "72px" }} />
                  </div>
                ))}
                {order.items.length > 4 && (
                  <div className="shrink-0 w-14 flex items-center justify-center text-xs text-muted-foreground">+{order.items.length - 4}</div>
                )}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
