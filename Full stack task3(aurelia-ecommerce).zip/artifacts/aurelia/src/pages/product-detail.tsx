import { useState } from "react";
import { useParams, Link, useLocation } from "wouter";
import { useGetProduct, useAddToCart, getGetCartQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { ShoppingBag, Star, ArrowRight, Minus, Plus } from "lucide-react";
import { useAuth } from "@/lib/auth";

export default function ProductDetail() {
  const { id } = useParams();
  const { data: product, isLoading, error } = useGetProduct(id!);
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const { toast } = useToast();
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const addToCartMutation = useAddToCart({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        toast({
          title: "Added to Cart",
          description: `${quantity}x ${product?.name} has been added to your cart.`,
          action: (
            <Button variant="outline" size="sm" onClick={() => setLocation("/cart")}>
              View Cart
            </Button>
          ),
        });
      },
      onError: (err: any) => {
        toast({
          title: "Could not add to cart",
          description: err.message || "Please try again later.",
          variant: "destructive"
        });
      }
    }
  });

  const handleAddToCart = () => {
    if (!user) {
      toast({
        title: "Please sign in",
        description: "You must be signed in to add items to your cart.",
        action: (
          <Button variant="outline" size="sm" onClick={() => setLocation("/login")}>
            Sign In
          </Button>
        )
      });
      return;
    }

    addToCartMutation.mutate({
      data: {
        productId: product!.id,
        quantity
      }
    });
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <Skeleton className="aspect-[3/4] w-full" />
          <div className="space-y-6 pt-8">
            <Skeleton className="h-10 w-2/3" />
            <Skeleton className="h-6 w-1/4" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center">
        <h2 className="text-2xl font-serif mb-4">Product Not Found</h2>
        <p className="text-muted-foreground mb-8">The piece you're looking for doesn't exist or has been removed.</p>
        <Link href="/products" className="text-primary hover:underline uppercase tracking-widest text-sm">
          Return to Collection
        </Link>
      </div>
    );
  }

  const hasImages = product.images && product.images.length > 0;
  const displayImages = hasImages ? product.images : ['https://via.placeholder.com/800x1000'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Breadcrumbs */}
      <nav className="flex text-sm text-muted-foreground mb-8" aria-label="Breadcrumb">
        <ol className="flex items-center space-x-2">
          <li><Link href="/" className="hover:text-primary">Home</Link></li>
          <li><span className="mx-2">/</span></li>
          <li><Link href={`/products?category=${product.category}`} className="hover:text-primary uppercase">{product.category}</Link></li>
          <li><span className="mx-2">/</span></li>
          <li className="text-foreground truncate max-w-[200px]" aria-current="page">{product.name}</li>
        </ol>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        {/* Images */}
        <div className="space-y-4">
          <div className="aspect-[3/4] bg-muted overflow-hidden">
            <img 
              src={displayImages[selectedImage]} 
              alt={product.name} 
              className="w-full h-full object-cover"
            />
          </div>
          {displayImages.length > 1 && (
            <div className="grid grid-cols-4 gap-4">
              {displayImages.map((img, idx) => (
                <button 
                  key={idx} 
                  onClick={() => setSelectedImage(idx)}
                  className={`aspect-square bg-muted overflow-hidden border-2 ${selectedImage === idx ? 'border-primary' : 'border-transparent'}`}
                >
                  <img src={img} alt={`${product.name} ${idx + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div className="flex flex-col pt-8">
          <div className="mb-2">
            <span className="text-xs tracking-widest uppercase text-muted-foreground">{product.category}</span>
          </div>
          <h1 className="text-4xl font-serif font-bold text-foreground mb-4">{product.name}</h1>
          
          <div className="flex items-center gap-4 mb-6">
            <div className="flex items-center gap-2">
              <span className="text-2xl font-medium">{formatCurrency(product.price)}</span>
              {product.comparePrice && (
                <span className="text-lg text-muted-foreground line-through">{formatCurrency(product.comparePrice)}</span>
              )}
            </div>
            
            {product.rating && (
              <div className="flex items-center gap-1 pl-4 border-l border-border">
                <Star className="w-4 h-4 fill-primary text-primary" />
                <span className="text-sm">{product.rating.toFixed(1)}</span>
                <span className="text-sm text-muted-foreground">({product.reviewCount})</span>
              </div>
            )}
          </div>

          <div className="prose prose-sm md:prose-base prose-neutral dark:prose-invert mb-10 max-w-none text-muted-foreground leading-relaxed">
            <p>{product.description}</p>
          </div>

          <div className="h-px bg-border w-full mb-8" />

          {/* Actions */}
          <div className="mt-auto space-y-6">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium uppercase tracking-wider">Quantity</span>
              <div className="flex items-center border border-border">
                <button 
                  className="p-3 hover:bg-muted transition-colors disabled:opacity-50"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1}
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-12 text-center font-medium">{quantity}</span>
                <button 
                  className="p-3 hover:bg-muted transition-colors disabled:opacity-50"
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  disabled={quantity >= product.stock}
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            <Button 
              className="w-full py-6 rounded-none tracking-widest uppercase text-sm"
              size="lg"
              disabled={product.stock <= 0 || addToCartMutation.isPending}
              onClick={handleAddToCart}
            >
              {addToCartMutation.isPending ? 'Adding...' : product.stock > 0 ? (
                <>
                  <ShoppingBag className="mr-2 h-4 w-4" /> Add to Cart
                </>
              ) : 'Out of Stock'}
            </Button>
            
            <div className="flex justify-center text-sm text-muted-foreground">
              {product.stock > 0 && product.stock < 5 && (
                <span className="text-destructive">Only {product.stock} left in stock</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
