import { Link, useLocation } from "wouter";
import { useGetCart, useUpdateCartItem, useRemoveFromCart, getGetCartQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Trash2, Minus, Plus, ArrowRight, ShoppingBag } from "lucide-react";

export default function Cart() {
  const { data: cart, isLoading } = useGetCart();
  const updateItemMutation = useUpdateCartItem();
  const removeItemMutation = useRemoveFromCart();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const handleUpdateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity < 1) return;
    updateItemMutation.mutate(
      { productId, data: { quantity: newQuantity } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }) }
    );
  };

  const handleRemoveItem = (productId: string) => {
    removeItemMutation.mutate(
      { productId },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }) }
    );
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl font-serif font-bold uppercase tracking-wider mb-8">Shopping Bag</h1>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 space-y-6">
            {[1, 2].map((i) => (
              <Skeleton key={i} className="h-32 w-full" />
            ))}
          </div>
          <div><Skeleton className="h-64 w-full" /></div>
        </div>
      </div>
    );
  }

  if (!cart || !cart.items || cart.items.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
        <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center mb-6">
          <ShoppingBag className="w-8 h-8 text-muted-foreground" />
        </div>
        <h2 className="text-2xl font-serif mb-4 uppercase tracking-wider">Your bag is empty</h2>
        <p className="text-muted-foreground mb-8 max-w-md">
          Discover our latest collection and find something exceptional to add to your wardrobe.
        </p>
        <Link href="/products">
          <Button className="rounded-none tracking-widest uppercase px-8">Continue Shopping</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-serif font-bold uppercase tracking-wider mb-8">Shopping Bag</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2">
          <div className="hidden md:grid grid-cols-12 text-sm text-muted-foreground uppercase tracking-widest pb-4 border-b border-border">
            <div className="col-span-6">Product</div>
            <div className="col-span-3 text-center">Quantity</div>
            <div className="col-span-3 text-right">Total</div>
          </div>
          
          <div className="divide-y divide-border">
            {cart.items.map((item) => (
              <div key={item.product.id} className="py-8 flex flex-col md:grid md:grid-cols-12 gap-4 items-center">
                <div className="col-span-6 flex items-center gap-6 w-full">
                  <Link href={`/products/${item.product.id}`} className="shrink-0">
                    <img 
                      src={item.product.images?.[0] || 'https://via.placeholder.com/150'} 
                      alt={item.product.name} 
                      className="w-24 h-32 object-cover bg-muted"
                    />
                  </Link>
                  <div className="flex flex-col h-32 justify-between py-2">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{item.product.category}</p>
                      <Link href={`/products/${item.product.id}`} className="font-medium hover:text-primary transition-colors line-clamp-2">
                        {item.product.name}
                      </Link>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-sm">{formatCurrency(item.price)}</span>
                      <button 
                        onClick={() => handleRemoveItem(item.product.id)}
                        className="text-xs text-muted-foreground hover:text-destructive flex items-center gap-1 uppercase tracking-wider"
                      >
                        <Trash2 className="w-3 h-3" /> Remove
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="col-span-3 flex justify-center w-full md:w-auto">
                  <div className="flex items-center border border-border">
                    <button 
                      className="p-2 hover:bg-muted transition-colors disabled:opacity-50"
                      onClick={() => handleUpdateQuantity(item.product.id, item.quantity - 1)}
                      disabled={item.quantity <= 1 || updateItemMutation.isPending}
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-10 text-center text-sm font-medium">{item.quantity}</span>
                    <button 
                      className="p-2 hover:bg-muted transition-colors disabled:opacity-50"
                      onClick={() => handleUpdateQuantity(item.product.id, item.quantity + 1)}
                      disabled={updateItemMutation.isPending}
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
                
                <div className="col-span-3 text-right font-medium w-full md:w-auto flex justify-between md:block">
                  <span className="md:hidden text-muted-foreground">Total:</span>
                  {formatCurrency(item.price * item.quantity)}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-secondary/30 p-8 border border-border/50 sticky top-24">
            <h2 className="text-xl font-serif font-bold uppercase tracking-wider mb-6">Order Summary</h2>
            
            <div className="space-y-4 text-sm mb-6">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal ({cart.itemCount} items)</span>
                <span>{formatCurrency(cart.total)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                <span>Calculated at checkout</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Taxes</span>
                <span>Calculated at checkout</span>
              </div>
            </div>
            
            <div className="h-px bg-border w-full mb-6" />
            
            <div className="flex justify-between font-medium text-lg mb-8">
              <span>Estimated Total</span>
              <span>{formatCurrency(cart.total)}</span>
            </div>
            
            <Button 
              className="w-full py-6 rounded-none tracking-widest uppercase text-sm"
              onClick={() => setLocation("/checkout")}
            >
              Proceed to Checkout <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            
            <div className="mt-6 text-center text-xs text-muted-foreground">
              Complimentary shipping and returns on all orders.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
