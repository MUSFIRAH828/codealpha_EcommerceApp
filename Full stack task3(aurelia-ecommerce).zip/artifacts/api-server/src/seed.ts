import { connectMongoDB } from "./lib/mongodb";
import { User } from "./models/user";
import { Product } from "./models/product";
import { logger } from "./lib/logger";

const categories = ["Handbags", "Shoes", "Watches", "Jewelry", "Sunglasses", "Scarves"];

const sampleProducts = [
  {
    name: "Onyx Structured Tote",
    description: "A refined structured tote crafted from full-grain Italian leather. The clean lines and polished hardware make it an impeccable companion for any occasion.",
    price: 1290,
    comparePrice: 1590,
    category: "Handbags",
    stock: 12,
    images: [],
    rating: 4.8,
    reviewCount: 124,
    featured: true,
    tags: ["leather", "tote", "luxury", "italian"],
  },
  {
    name: "Champagne Evening Clutch",
    description: "A luminous satin clutch with a delicate champagne finish and gold-toned clasp. Designed for evenings that deserve to be remembered.",
    price: 490,
    comparePrice: null,
    category: "Handbags",
    stock: 8,
    images: [],
    rating: 4.6,
    reviewCount: 67,
    featured: true,
    tags: ["clutch", "evening", "satin", "gold"],
  },
  {
    name: "Noir Stiletto Pump",
    description: "A timeless stiletto pump in supple patent leather. The perfectly tapered heel and pointed toe are tailored for the discerning woman.",
    price: 680,
    comparePrice: null,
    category: "Shoes",
    stock: 20,
    images: [],
    rating: 4.9,
    reviewCount: 203,
    featured: true,
    tags: ["heels", "patent", "stiletto", "classic"],
  },
  {
    name: "Cashmere Mule",
    description: "Slide into effortless elegance with these cashmere-lined mules. A rounded toe and block heel deliver comfort without compromise.",
    price: 420,
    comparePrice: 520,
    category: "Shoes",
    stock: 15,
    images: [],
    rating: 4.5,
    reviewCount: 89,
    featured: false,
    tags: ["mules", "cashmere", "comfort", "block-heel"],
  },
  {
    name: "Aurelia Perpetual Chrono",
    description: "A precision-engineered chronograph with a sapphire crystal face and 18k rose gold case. Powered by a Swiss automatic movement, it is built to last generations.",
    price: 4800,
    comparePrice: null,
    category: "Watches",
    stock: 5,
    images: [],
    rating: 5.0,
    reviewCount: 42,
    featured: true,
    tags: ["chronograph", "swiss", "rose-gold", "automatic"],
  },
  {
    name: "Slim Milanese Watch",
    description: "A slim stainless steel case on a brushed Milanese mesh bracelet. Minimalist design for the modern collector.",
    price: 1650,
    comparePrice: 1900,
    category: "Watches",
    stock: 9,
    images: [],
    rating: 4.7,
    reviewCount: 78,
    featured: false,
    tags: ["minimalist", "milanese", "stainless", "slim"],
  },
  {
    name: "18k Diamond Pavé Bangle",
    description: "A brilliant bangle set with hand-selected pavé diamonds in 18k white gold. A piece to cherish, and to pass on.",
    price: 3200,
    comparePrice: null,
    category: "Jewelry",
    stock: 6,
    images: [],
    rating: 4.9,
    reviewCount: 55,
    featured: true,
    tags: ["diamond", "gold", "bangle", "pavé"],
  },
  {
    name: "Baroque Pearl Drop Earrings",
    description: "Naturally asymmetric baroque pearls suspended from fine yellow gold hooks. Each pair is one-of-a-kind.",
    price: 780,
    comparePrice: null,
    category: "Jewelry",
    stock: 14,
    images: [],
    rating: 4.6,
    reviewCount: 91,
    featured: false,
    tags: ["pearl", "earrings", "baroque", "gold"],
  },
  {
    name: "Smoke Shield Aviators",
    description: "Oversized titanium aviators with polarized smoke lenses and gold-flash detailing. UV400 protection with an unmistakable silhouette.",
    price: 395,
    comparePrice: 480,
    category: "Sunglasses",
    stock: 25,
    images: [],
    rating: 4.4,
    reviewCount: 147,
    featured: false,
    tags: ["aviator", "polarized", "titanium", "oversized"],
  },
  {
    name: "Crystal Cat-Eye",
    description: "A bold cat-eye frame in acetate with a crystal-clear tint. The sculptural arms and subtle gradient lens give it unmistakable presence.",
    price: 320,
    comparePrice: null,
    category: "Sunglasses",
    stock: 18,
    images: [],
    rating: 4.7,
    reviewCount: 112,
    featured: true,
    tags: ["cat-eye", "acetate", "gradient", "bold"],
  },
  {
    name: "Cashmere Plaid Shawl",
    description: "Woven from 100% grade-A Mongolian cashmere, this oversized plaid shawl drapes with effortless warmth. An heirloom piece for every season.",
    price: 590,
    comparePrice: 720,
    category: "Scarves",
    stock: 22,
    images: [],
    rating: 4.8,
    reviewCount: 68,
    featured: false,
    tags: ["cashmere", "plaid", "shawl", "winter"],
  },
  {
    name: "Silk Jacquard Scarf",
    description: "A 90cm silk twill scarf in a hand-drawn jacquard print. Tumbling flora on ivory — a collector's piece for those who appreciate print.",
    price: 360,
    comparePrice: null,
    category: "Scarves",
    stock: 30,
    images: [],
    rating: 4.5,
    reviewCount: 83,
    featured: false,
    tags: ["silk", "jacquard", "print", "twill"],
  },
];

export async function seedDatabase() {
  await connectMongoDB();

  const productCount = await Product.countDocuments();
  if (productCount === 0) {
    await Product.insertMany(sampleProducts);
    logger.info(`Seeded ${sampleProducts.length} products`);
  }

  const adminExists = await User.findOne({ role: "admin" });
  if (!adminExists) {
    await User.create({
      name: "Admin User",
      email: "admin@aurelia.com",
      password: "admin123",
      role: "admin",
    });
    logger.info("Seeded admin user: admin@aurelia.com / admin123");
  }
}
