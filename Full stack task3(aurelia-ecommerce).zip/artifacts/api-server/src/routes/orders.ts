import { Router } from "express";
import mongoose from "mongoose";
import { Order } from "../models/order";
import { Cart } from "../models/cart";
import { authenticate, type AuthRequest } from "../middlewares/auth";

const router = Router();

function formatOrder(order: unknown) {
  const o = order as Record<string, unknown>;
  return {
    ...o,
    id: String(o._id),
    user: String(o.user),
    items: (o.items as Array<Record<string, unknown>>).map((item) => ({
      ...item,
      product: String(item.product),
    })),
  };
}

router.get("/orders", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const orders = await Order.find({ user: req.userId! }).sort({ createdAt: -1 }).lean();
  res.json(orders.map(formatOrder));
});

router.post("/orders", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const { shippingAddress, paymentMethod } = req.body;

  if (!shippingAddress) {
    res.status(400).json({ error: "shippingAddress is required" });
    return;
  }

  const cart = await Cart.findOne({ user: req.userId! }).populate("items.product").lean();
  if (!cart || cart.items.length === 0) {
    res.status(400).json({ error: "Cart is empty" });
    return;
  }

  let total = 0;
  const items: {
    product: mongoose.Types.ObjectId;
    name: string;
    quantity: number;
    price: number;
    image: string;
  }[] = [];

  for (const item of cart.items) {
    if (item.product == null) continue;
    const product = item.product as unknown as Record<string, unknown>;
    const lineTotal = item.price * item.quantity;
    total += lineTotal;
    items.push({
      product: new mongoose.Types.ObjectId(String(product._id)),
      name: String(product.name),
      quantity: item.quantity,
      price: item.price,
      image:
        Array.isArray(product.images) && product.images.length > 0
          ? String(product.images[0])
          : "",
    });
  }

  const orderDoc = await Order.create({
    user: req.userId!,
    items,
    shippingAddress,
    paymentMethod: paymentMethod || "card",
    total,
    isPaid: false,
    status: "pending",
  });

  await Cart.findOneAndUpdate({ user: req.userId! }, { $set: { items: [] } });

  res.status(201).json(formatOrder(orderDoc.toObject()));
});

router.get("/orders/:id", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const order = await Order.findOne({ _id: raw, user: req.userId! }).lean();
  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }
  res.json(formatOrder(order));
});

export default router;
