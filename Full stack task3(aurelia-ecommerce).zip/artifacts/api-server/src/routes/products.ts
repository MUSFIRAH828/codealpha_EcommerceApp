import { Router, type IRouter } from "express";
import { SortOrder } from "mongoose";
import { Product } from "../models/product";
import { requireAdmin, type AuthRequest } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/products", async (req, res): Promise<void> => {
  const { q, category, minPrice, maxPrice, sort, page = 1, limit = 12 } = req.query;

  const filter: Record<string, unknown> = {};

  if (q && typeof q === "string" && q.trim()) {
    filter.$text = { $search: q };
  }

  if (category && typeof category === "string") {
    filter.category = category;
  }

  if (minPrice || maxPrice) {
    const priceFilter: Record<string, number> = {};
    if (minPrice) priceFilter.$gte = Number(minPrice);
    if (maxPrice) priceFilter.$lte = Number(maxPrice);
    filter.price = priceFilter;
  }

  let sortObj: Record<string, SortOrder> = { createdAt: -1 };
  if (sort === "price_asc") sortObj = { price: 1 };
  else if (sort === "price_desc") sortObj = { price: -1 };
  else if (sort === "rating") sortObj = { rating: -1 };
  else if (sort === "newest") sortObj = { createdAt: -1 };

  const pageNum = Math.max(1, Number(page));
  const limitNum = Math.min(50, Math.max(1, Number(limit)));
  const skip = (pageNum - 1) * limitNum;

  const [products, total] = await Promise.all([
    Product.find(filter).sort(sortObj).skip(skip).limit(limitNum).lean(),
    Product.countDocuments(filter),
  ]);

  res.json({
    products: products.map((p) => ({ ...p, id: String(p._id) })),
    total,
    page: pageNum,
    pages: Math.ceil(total / limitNum),
  });
});

router.get("/products/featured", async (_req, res): Promise<void> => {
  const products = await Product.find({ featured: true }).limit(8).lean();
  res.json(products.map((p) => ({ ...p, id: String(p._id) })));
});

router.get("/products/categories", async (_req, res): Promise<void> => {
  const agg = await Product.aggregate([
    { $group: { _id: "$category", count: { $sum: 1 } } },
    { $sort: { count: -1 } },
  ]);
  res.json(agg.map((a) => ({ name: a._id, count: a.count })));
});

router.get("/products/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const product = await Product.findById(raw).lean();
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.json({ ...product, id: String(product._id) });
});

router.post("/products", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const product = await Product.create(req.body);
  const p = product.toObject();
  res.status(201).json({ ...p, id: String(p._id) });
});

router.put("/products/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const product = await Product.findByIdAndUpdate(raw, req.body, { new: true }).lean();
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.json({ ...product, id: String(product._id) });
});

router.delete("/products/:id", requireAdmin, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const product = await Product.findByIdAndDelete(raw);
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
