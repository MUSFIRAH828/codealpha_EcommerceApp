import { Router } from "express";
import { Cart } from "../models/cart";
import { Product } from "../models/product";
import { authenticate, type AuthRequest } from "../middlewares/auth";
import mongoose from "mongoose";

const router = Router();

async function getPopulatedCart(userId: string) {
  const cart = await Cart.findOne({ user: userId }).populate("items.product").lean();
  if (!cart) return { items: [], total: 0, itemCount: 0 };

  let total = 0;
  let itemCount = 0;

  const items = cart.items
    .filter((item) => item.product != null)
    .map((item) => {
      const product = item.product as unknown as Record<string, unknown>;
      const price = item.price;
      total += price * item.quantity;
      itemCount += item.quantity;
      return {
        product: { ...product, id: String(product._id) },
        quantity: item.quantity,
        price,
      };
    });

  return { items, total, itemCount };
}

router.get("/cart", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const data = await getPopulatedCart(req.userId!);
  res.json(data);
});

router.post("/cart/items", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const { productId, quantity } = req.body;
  if (!productId || !quantity || quantity < 1) {
    res.status(400).json({ error: "productId and quantity (>=1) are required" });
    return;
  }

  const product = await Product.findById(productId).lean();
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  let cart = await Cart.findOne({ user: req.userId! });
  if (!cart) {
    cart = await Cart.create({ user: req.userId!, items: [] });
  }

  const existingIdx = cart.items.findIndex(
    (item) => String(item.product) === String(productId)
  );

  if (existingIdx >= 0) {
    cart.items[existingIdx].quantity += quantity;
  } else {
    cart.items.push({
      product: new mongoose.Types.ObjectId(productId),
      quantity,
      price: product.price,
    });
  }

  await cart.save();
  const data = await getPopulatedCart(req.userId!);
  res.json(data);
});

router.put("/cart/items/:productId", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.productId) ? req.params.productId[0] : req.params.productId;
  const { quantity } = req.body;

  if (!quantity || quantity < 1) {
    res.status(400).json({ error: "quantity must be >= 1" });
    return;
  }

  const cart = await Cart.findOne({ user: req.userId! });
  if (!cart) {
    res.status(404).json({ error: "Cart not found" });
    return;
  }

  const item = cart.items.find((i) => String(i.product) === raw);
  if (!item) {
    res.status(404).json({ error: "Item not in cart" });
    return;
  }

  item.quantity = quantity;
  await cart.save();

  const data = await getPopulatedCart(req.userId!);
  res.json(data);
});

router.delete("/cart/items/:productId", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.productId) ? req.params.productId[0] : req.params.productId;

  const cart = await Cart.findOne({ user: req.userId! });
  if (!cart) {
    res.status(404).json({ error: "Cart not found" });
    return;
  }

  cart.items = cart.items.filter((i) => String(i.product) !== raw);
  await cart.save();

  const data = await getPopulatedCart(req.userId!);
  res.json(data);
});

router.delete("/cart/clear", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const cart = await Cart.findOne({ user: req.userId! });
  if (cart) {
    cart.items = [];
    await cart.save();
  }
  res.json({ items: [], total: 0, itemCount: 0 });
});

export default router;
