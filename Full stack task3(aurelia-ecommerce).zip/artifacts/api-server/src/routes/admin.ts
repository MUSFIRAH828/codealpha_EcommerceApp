import { Router } from "express";
import { Order } from "../models/order";
import { Product } from "../models/product";
import { User } from "../models/user";
import { requireAdmin, type AuthRequest } from "../middlewares/auth";

const router = Router();

function formatOrder(order: unknown) {
  const o = order as Record<string, unknown>;
  return {
    ...o,
    id: String(o._id),
    user: String(o.user),
    items: (o.items as Array<Record<string, unknown>>).map((item) => ({
      ...item,
      product: String(item.product),
    })),
  };
}

router.get("/admin/orders", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const orders = await Order.find().sort({ createdAt: -1 }).lean();
  res.json(orders.map(formatOrder));
});

router.patch(
  "/admin/orders/:id/status",
  requireAdmin,
  async (req: AuthRequest, res): Promise<void> => {
    const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
    const { status } = req.body;
    const validStatuses = ["pending", "processing", "shipped", "delivered", "cancelled"];
    if (!validStatuses.includes(status)) {
      res.status(400).json({ error: "Invalid status" });
      return;
    }

    const order = await Order.findByIdAndUpdate(raw, { status }, { new: true }).lean();
    if (!order) {
      res.status(404).json({ error: "Order not found" });
      return;
    }
    res.json(formatOrder(order));
  }
);

router.get("/admin/stats", requireAdmin, async (_req: AuthRequest, res): Promise<void> => {
  const [totalOrders, totalProducts, totalUsers, orders, products] = await Promise.all([
    Order.countDocuments(),
    Product.countDocuments(),
    User.countDocuments(),
    Order.find().sort({ createdAt: -1 }).limit(100).lean(),
    Product.find().sort({ rating: -1 }).limit(6).lean(),
  ]);

  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const recentOrders = orders.slice(0, 8).map(formatOrder);

  const ordersByStatus: Record<string, number> = {};
  for (const o of orders) {
    ordersByStatus[o.status] = (ordersByStatus[o.status] || 0) + 1;
  }

  const revenueByMonthMap: Record<string, number> = {};
  for (const o of orders) {
    const d = new Date(o.createdAt);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    revenueByMonthMap[key] = (revenueByMonthMap[key] || 0) + o.total;
  }
  const revenueByMonth = Object.entries(revenueByMonthMap)
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-12)
    .map(([month, revenue]) => ({ month, revenue }));

  res.json({
    totalRevenue,
    totalOrders,
    totalProducts,
    totalUsers,
    recentOrders,
    topProducts: products.map((p) => ({ ...p, id: String(p._id) })),
    ordersByStatus: Object.entries(ordersByStatus).map(([status, count]) => ({ status, count })),
    revenueByMonth,
  });
});

export default router;
