# Screenshots

Place your application screenshots here after running the project.

Suggested filenames:
- login.png       → Login / Sign-up page
- dashboard.png   → Main dashboard with stats
- kanban.png      → Kanban board with tasks
- analytics.png   → Analytics charts page

These can be used in your README or documentation.
