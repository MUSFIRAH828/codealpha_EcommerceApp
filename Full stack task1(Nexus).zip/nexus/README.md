# NEXUS — Full-Stack Project Management Platform

> A production-ready project management platform with authentication, Kanban boards, dashboards, and analytics.

---

## 🚀 Tech Stack

| Layer      | Tech                          |
|------------|-------------------------------|
| Frontend   | React 18 + Vite + Tailwind CSS |
| Backend    | Node.js + Express             |
| Database   | MongoDB + Mongoose            |
| Auth       | JWT (access + refresh tokens) |

---

## 📁 Folder Structure

```
nexus/
├── client/               # React frontend (Vite)
│   ├── src/
│   │   ├── components/   # Reusable UI components
│   │   ├── pages/        # Route-level pages
│   │   ├── context/      # React context (auth, theme)
│   │   ├── hooks/        # Custom hooks
│   │   └── utils/        # API helpers
│   └── ...
├── server/               # Express backend
│   ├── controllers/      # Route controllers
│   ├── middleware/        # Auth + error middleware
│   ├── models/           # Mongoose schemas
│   ├── routes/           # API routes
│   └── config/           # DB + env config
├── screenshots/          # App screenshots (add yours here)
├── .env.example          # Environment variable template
└── README.md
```

---

## ⚙️ Setup Instructions

### Prerequisites
- Node.js >= 18
- MongoDB (local or [MongoDB Atlas](https://www.mongodb.com/atlas))
- npm or yarn

---

### 1. Clone & Install

```bash
git clone <your-repo-url>
cd nexus

# Install server deps
cd server && npm install

# Install client deps
cd ../client && npm install
```

### 2. Configure Environment Variables

```bash
# In /server, copy the example file
cp ../.env.example server/.env
```

Edit `server/.env` with your values:

```env
MONGO_URI=mongodb://localhost:27017/nexus
JWT_SECRET=your_super_secret_key_here
JWT_REFRESH_SECRET=your_refresh_secret_here
PORT=5000
CLIENT_URL=http://localhost:5173
```

### 3. Run in Development

```bash
# Terminal 1 — Start backend
cd server
npm run dev

# Terminal 2 — Start frontend
cd client
npm run dev
```

Frontend: http://localhost:5173  
Backend API: http://localhost:5000

---

### 4. Build for Production

```bash
# Build frontend
cd client && npm run build

# Start production server (serves built frontend too)
cd server && npm start
```

---

## 🔐 API Endpoints

| Method | Route                   | Description          | Auth |
|--------|-------------------------|----------------------|------|
| POST   | /api/auth/register      | Register user        | ❌   |
| POST   | /api/auth/login         | Login user           | ❌   |
| POST   | /api/auth/refresh       | Refresh access token | ❌   |
| GET    | /api/auth/me            | Get current user     | ✅   |
| GET    | /api/tasks              | Get all tasks        | ✅   |
| POST   | /api/tasks              | Create task          | ✅   |
| PUT    | /api/tasks/:id          | Update task          | ✅   |
| DELETE | /api/tasks/:id          | Delete task          | ✅   |
| GET    | /api/analytics          | Get analytics data   | ✅   |

---

## 📸 Screenshots

Place your screenshots in the `/screenshots` folder:
- `login.png` — Login page
- `dashboard.png` — Dashboard overview
- `kanban.png` — Kanban board
- `analytics.png` — Analytics page

---

## 🛡️ Security Features

- JWT access tokens (15min expiry)
- Refresh token rotation
- Password hashing with bcrypt
- CORS configured for specific origin
- Rate limiting ready (add `express-rate-limit`)
- Helmet.js for HTTP headers

---

## 📄 License

MIT
