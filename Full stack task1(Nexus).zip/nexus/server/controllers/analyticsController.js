const Task = require('../models/Task');

exports.getAnalytics = async (req, res) => {
  try {
    const userId = req.user._id;

    const [statusCounts, priorityCounts, recentTasks, totalTasks] = await Promise.all([
      Task.aggregate([
        { $match: { user: userId } },
        { $group: { _id: '$status', count: { $sum: 1 } } },
      ]),
      Task.aggregate([
        { $match: { user: userId } },
        { $group: { _id: '$priority', count: { $sum: 1 } } },
      ]),
      Task.find({ user: userId }).sort({ createdAt: -1 }).limit(5),
      Task.countDocuments({ user: userId }),
    ]);

    // Tasks created per day (last 7 days)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const dailyActivity = await Task.aggregate([
      { $match: { user: userId, createdAt: { $gte: sevenDaysAgo } } },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    const completedTasks = statusCounts.find(s => s._id === 'done')?.count || 0;
    const completionRate = totalTasks ? Math.round((completedTasks / totalTasks) * 100) : 0;

    res.json({
      totalTasks,
      completedTasks,
      completionRate,
      statusCounts,
      priorityCounts,
      dailyActivity,
      recentTasks,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
