import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import { CheckCircle2, Clock, Layers, TrendingUp, ArrowRight, Plus, Zap } from 'lucide-react';

const STATUS_LABELS = { todo: 'To Do', 'in-progress': 'In Progress', review: 'Review', done: 'Done' };
const PRIORITY_COLORS = { low: 'tag-low', medium: 'tag-medium', high: 'tag-high', critical: 'tag-critical' };
const STATUS_COLORS = { todo: 'tag-todo', 'in-progress': 'tag-in-progress', review: 'tag-review', done: 'tag-done' };

function StatCard({ icon: Icon, label, value, sub, color }) {
  return (
    <div className="card p-6 flex items-start gap-4 hover:border-accent/30 transition-colors">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
        <Icon size={20} />
      </div>
      <div>
        <div className="text-2xl font-display font-bold text-text">{value}</div>
        <div className="text-sm font-body font-medium text-text mt-0.5">{label}</div>
        {sub && <div className="text-xs text-muted mt-1 font-mono">{sub}</div>}
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/tasks').then(({ data }) => setTasks(data)).finally(() => setLoading(false));
  }, []);

  const total = tasks.length;
  const done = tasks.filter(t => t.status === 'done').length;
  const inProgress = tasks.filter(t => t.status === 'in-progress').length;
  const completionRate = total ? Math.round((done / total) * 100) : 0;
  const recent = tasks.slice(0, 5);

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <div className="space-y-8 animate-slide-up">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-text">
            {greeting()}, {user?.name?.split(' ')[0]} 👋
          </h1>
          <p className="text-dim font-body mt-1">Here's what's happening with your projects.</p>
        </div>
        <Link to="/kanban" className="btn-primary flex items-center gap-2 text-sm">
          <Plus size={16} />
          New Task
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Layers} label="Total Tasks" value={total} sub="All time" color="bg-accent/10 text-accent" />
        <StatCard icon={Clock} label="In Progress" value={inProgress} sub="Active now" color="bg-cyan/10 text-cyan" />
        <StatCard icon={CheckCircle2} label="Completed" value={done} sub="Tasks done" color="bg-emerald/10 text-emerald" />
        <StatCard icon={TrendingUp} label="Completion" value={`${completionRate}%`} sub="Success rate" color="bg-amber/10 text-amber" />
      </div>

      {/* Progress bar */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="font-display font-semibold text-text">Overall Progress</h2>
            <p className="text-xs text-muted mt-0.5 font-mono">{done} of {total} tasks completed</p>
          </div>
          <span className="font-display text-2xl font-bold text-accent">{completionRate}%</span>
        </div>
        <div className="h-2 bg-surface rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-accent to-cyan rounded-full transition-all duration-700"
            style={{ width: `${completionRate}%` }}
          />
        </div>
        {/* Status breakdown */}
        <div className="grid grid-cols-4 gap-2 mt-4">
          {Object.entries(STATUS_LABELS).map(([key, label]) => {
            const count = tasks.filter(t => t.status === key).length;
            return (
              <div key={key} className="text-center">
                <div className="text-lg font-display font-bold text-text">{count}</div>
                <div className="text-xs text-muted font-body">{label}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Tasks */}
      <div className="card">
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="font-display font-semibold text-text">Recent Tasks</h2>
          <Link to="/kanban" className="text-sm text-accent hover:underline flex items-center gap-1 font-body">
            View all <ArrowRight size={14} />
          </Link>
        </div>

        {loading ? (
          <div className="p-8 text-center text-muted">
            <div className="w-6 h-6 border-2 border-accent border-t-transparent rounded-full animate-spin mx-auto" />
          </div>
        ) : recent.length === 0 ? (
          <div className="p-8 text-center text-muted font-body">
            <Zap size={32} className="mx-auto mb-3 text-muted/50" />
            <p>No tasks yet. <Link to="/kanban" className="text-accent hover:underline">Create your first one</Link></p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {recent.map(task => (
              <div key={task._id} className="flex items-center gap-4 px-6 py-4 hover:bg-white/[0.02] transition-colors">
                <div className="flex-1 min-w-0">
                  <div className="font-body font-medium text-text truncate">{task.title}</div>
                  {task.description && (
                    <div className="text-xs text-muted truncate mt-0.5">{task.description}</div>
                  )}
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className={`badge ${PRIORITY_COLORS[task.priority]}`}>{task.priority}</span>
                  <span className={`badge ${STATUS_COLORS[task.status]}`}>{STATUS_LABELS[task.status]}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
