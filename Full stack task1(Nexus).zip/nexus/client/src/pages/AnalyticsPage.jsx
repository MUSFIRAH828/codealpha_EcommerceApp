import { useState, useEffect } from 'react';
import api from '../utils/api';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, CartesianGrid, Legend,
} from 'recharts';
import { TrendingUp, CheckCircle2, Layers, Target } from 'lucide-react';

const STATUS_COLORS = {
  todo: '#4A5568',
  'in-progress': '#5B8EFF',
  review: '#FFB347',
  done: '#00E5A0',
};

const PRIORITY_COLORS = {
  low: '#00E5A0',
  medium: '#FFB347',
  high: '#FF5C7A',
  critical: '#FF5C7A',
};

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-panel border border-border rounded-lg px-3 py-2 shadow-card text-xs font-mono">
      <div className="text-dim mb-1">{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color || p.fill }}>{p.name}: {p.value}</div>
      ))}
    </div>
  );
};

function StatTile({ icon: Icon, label, value, color }) {
  return (
    <div className="card p-5 flex items-center gap-4">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
        <Icon size={20} />
      </div>
      <div>
        <div className="font-display text-2xl font-bold text-text">{value}</div>
        <div className="text-xs text-muted font-body">{label}</div>
      </div>
    </div>
  );
}

export default function AnalyticsPage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/analytics').then(({ data }) => setData(data)).finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="flex justify-center pt-16">
      <div className="w-8 h-8 border-2 border-accent border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (!data) return <div className="text-muted text-center pt-16">Failed to load analytics</div>;

  const statusData = data.statusCounts.map(s => ({
    name: s._id.replace('-', ' '),
    value: s.count,
    fill: STATUS_COLORS[s._id] || '#4A5568',
  }));

  const priorityData = data.priorityCounts.map(p => ({
    name: p._id,
    count: p.count,
    fill: PRIORITY_COLORS[p._id] || '#4A5568',
  }));

  const activityData = data.dailyActivity.map(d => ({
    date: d._id.slice(5), // MM-DD
    tasks: d.count,
  }));

  return (
    <div className="space-y-8 animate-slide-up">
      <div>
        <h1 className="font-display text-3xl font-bold text-text">Analytics</h1>
        <p className="text-dim font-body mt-1">Insights into your productivity and task management.</p>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatTile icon={Layers} label="Total Tasks" value={data.totalTasks} color="bg-accent/10 text-accent" />
        <StatTile icon={CheckCircle2} label="Completed" value={data.completedTasks} color="bg-emerald/10 text-emerald" />
        <StatTile icon={Target} label="Completion Rate" value={`${data.completionRate}%`} color="bg-amber/10 text-amber" />
        <StatTile icon={TrendingUp} label="This Week" value={data.dailyActivity.reduce((a, d) => a + d.count, 0)} color="bg-cyan/10 text-cyan" />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Status pie */}
        <div className="card p-6">
          <h2 className="font-display font-semibold text-text mb-6">Tasks by Status</h2>
          {statusData.length === 0 ? (
            <div className="text-center text-muted text-sm py-12">No data yet</div>
          ) : (
            <div className="flex items-center gap-6">
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%"
                    innerRadius={50} outerRadius={75} paddingAngle={3}>
                    {statusData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-2 min-w-[120px]">
                {statusData.map(s => (
                  <div key={s.name} className="flex items-center gap-2 text-xs font-body">
                    <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: s.fill }} />
                    <span className="text-dim capitalize">{s.name}</span>
                    <span className="text-text font-mono ml-auto">{s.value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Priority bar */}
        <div className="card p-6">
          <h2 className="font-display font-semibold text-text mb-6">Tasks by Priority</h2>
          {priorityData.length === 0 ? (
            <div className="text-center text-muted text-sm py-12">No data yet</div>
          ) : (
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={priorityData} barSize={28}>
                <XAxis dataKey="name" tick={{ fill: '#8892A4', fontSize: 12, fontFamily: 'DM Sans' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#8892A4', fontSize: 12 }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {priorityData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Daily activity */}
      <div className="card p-6">
        <h2 className="font-display font-semibold text-text mb-6">Task Activity (Last 7 Days)</h2>
        {activityData.length === 0 ? (
          <div className="text-center text-muted text-sm py-12">No activity data for this period</div>
        ) : (
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={activityData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="date" tick={{ fill: '#8892A4', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#8892A4', fontSize: 12 }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="tasks" stroke="#5B8EFF" strokeWidth={2.5}
                dot={{ fill: '#5B8EFF', r: 4 }} activeDot={{ r: 6, fill: '#00D4FF' }} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Recent tasks table */}
      {data.recentTasks?.length > 0 && (
        <div className="card">
          <div className="p-6 border-b border-border">
            <h2 className="font-display font-semibold text-text">Recently Created</h2>
          </div>
          <div className="divide-y divide-border">
            {data.recentTasks.map(task => (
              <div key={task._id} className="flex items-center gap-4 px-6 py-3">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-body font-medium text-text truncate">{task.title}</div>
                  <div className="text-xs text-muted font-mono">
                    {new Date(task.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <span className={`badge tag-${task.status}`}>{task.status.replace('-', ' ')}</span>
                  <span className={`badge tag-${task.priority}`}>{task.priority}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
