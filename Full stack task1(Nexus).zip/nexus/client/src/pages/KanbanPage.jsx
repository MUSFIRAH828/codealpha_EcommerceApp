import { useState, useEffect } from 'react';
import api from '../utils/api';
import KanbanCard from '../components/kanban/KanbanCard';
import TaskModal from '../components/kanban/TaskModal';
import { Plus, Search } from 'lucide-react';

const COLUMNS = [
  { id: 'todo', label: 'To Do', color: 'text-dim', dot: 'bg-muted' },
  { id: 'in-progress', label: 'In Progress', color: 'text-accent', dot: 'bg-accent' },
  { id: 'review', label: 'Review', color: 'text-amber', dot: 'bg-amber' },
  { id: 'done', label: 'Done', color: 'text-emerald', dot: 'bg-emerald' },
];

export default function KanbanPage() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(null); // null | { task, defaultStatus }
  const [search, setSearch] = useState('');

  const fetchTasks = () => {
    api.get('/tasks').then(({ data }) => setTasks(data)).finally(() => setLoading(false));
  };

  useEffect(() => { fetchTasks(); }, []);

  const filtered = tasks.filter(t =>
    t.title.toLowerCase().includes(search.toLowerCase()) ||
    t.description?.toLowerCase().includes(search.toLowerCase()) ||
    t.tags?.some(tag => tag.toLowerCase().includes(search.toLowerCase()))
  );

  const columnTasks = (col) => filtered.filter(t => t.status === col);

  const openNew = (status = 'todo') => setModal({ task: { status }, defaultStatus: status });
  const openEdit = (task) => setModal({ task });
  const closeModal = () => setModal(null);

  const saveTask = async (formData) => {
    if (modal.task._id) {
      const { data } = await api.put(`/tasks/${modal.task._id}`, formData);
      setTasks(prev => prev.map(t => t._id === data._id ? data : t));
    } else {
      const { data } = await api.post('/tasks', formData);
      setTasks(prev => [data, ...prev]);
    }
  };

  const deleteTask = async (id) => {
    if (!confirm('Delete this task?')) return;
    await api.delete(`/tasks/${id}`);
    setTasks(prev => prev.filter(t => t._id !== id));
  };

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-text">Kanban Board</h1>
          <p className="text-dim font-body mt-1">{tasks.length} tasks across {COLUMNS.length} columns</p>
        </div>
        <div className="flex gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
            <input
              value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search tasks…"
              className="input pl-9 w-48 text-sm"
            />
          </div>
          <button onClick={() => openNew()} className="btn-primary flex items-center gap-2 text-sm">
            <Plus size={16} />
            New Task
          </button>
        </div>
      </div>

      {/* Board */}
      {loading ? (
        <div className="flex justify-center pt-16">
          <div className="w-8 h-8 border-2 border-accent border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 items-start">
          {COLUMNS.map(col => {
            const colTasks = columnTasks(col.id);
            return (
              <div key={col.id} className="card flex flex-col min-h-[200px]">
                {/* Column header */}
                <div className="flex items-center justify-between p-4 border-b border-border">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${col.dot}`} />
                    <span className={`font-display font-semibold text-sm ${col.color}`}>{col.label}</span>
                    <span className="text-xs text-muted font-mono bg-surface px-1.5 py-0.5 rounded">
                      {colTasks.length}
                    </span>
                  </div>
                  <button onClick={() => openNew(col.id)}
                    className="text-muted hover:text-accent transition-colors p-1 rounded hover:bg-accent/10">
                    <Plus size={16} />
                  </button>
                </div>

                {/* Cards */}
                <div className="flex flex-col gap-2 p-3 flex-1">
                  {colTasks.length === 0 ? (
                    <div className="flex-1 flex items-center justify-center text-muted text-xs font-body py-6">
                      No tasks
                    </div>
                  ) : (
                    colTasks.map(task => (
                      <KanbanCard key={task._id} task={task} onEdit={openEdit} onDelete={deleteTask} />
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modal && (
        <TaskModal task={modal.task} onSave={saveTask} onClose={closeModal} />
      )}
    </div>
  );
}
