import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { LayoutDashboard, Columns3, BarChart3, LogOut, Zap, Menu, X } from 'lucide-react';
import { useState } from 'react';

const navItems = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/kanban', icon: Columns3, label: 'Kanban' },
  { to: '/analytics', icon: BarChart3, label: 'Analytics' },
];

export default function AppLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/login'); };

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center shadow-glow">
            <Zap size={16} className="text-white" fill="white" />
          </div>
          <span className="font-display font-800 text-xl text-text tracking-tight">NEXUS</span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map(({ to, icon: Icon, label }) => (
          <NavLink key={to} to={to} onClick={() => setSidebarOpen(false)}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-lg font-body font-medium text-sm transition-all duration-200 ${
                isActive
                  ? 'bg-accent/10 text-accent border border-accent/20 shadow-glow-sm'
                  : 'text-dim hover:text-text hover:bg-white/5'
              }`
            }
          >
            <Icon size={18} />
            {label}
          </NavLink>
        ))}
      </nav>

      {/* User */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center gap-3 px-2 mb-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent to-cyan flex items-center justify-center text-xs font-display font-bold text-void">
            {user?.name?.[0]?.toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-body font-medium text-text truncate">{user?.name}</div>
            <div className="text-xs text-muted truncate">{user?.email}</div>
          </div>
        </div>
        <button onClick={handleLogout}
          className="flex items-center gap-3 w-full px-4 py-2.5 rounded-lg text-sm text-dim hover:text-rose hover:bg-rose/10 transition-all duration-200 font-body"
        >
          <LogOut size={16} />
          Sign out
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-void flex bg-grid-pattern bg-grid">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex w-60 bg-panel/80 backdrop-blur border-r border-border flex-col fixed h-full z-20">
        <SidebarContent />
      </aside>

      {/* Mobile sidebar */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="relative w-64 bg-panel border-r border-border flex flex-col">
            <button onClick={() => setSidebarOpen(false)} className="absolute top-4 right-4 text-dim hover:text-text">
              <X size={20} />
            </button>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main */}
      <main className="flex-1 lg:ml-60 flex flex-col min-h-screen">
        {/* Mobile topbar */}
        <div className="lg:hidden flex items-center gap-4 p-4 border-b border-border bg-panel/80 backdrop-blur sticky top-0 z-10">
          <button onClick={() => setSidebarOpen(true)} className="text-dim hover:text-text">
            <Menu size={22} />
          </button>
          <div className="flex items-center gap-2">
            <Zap size={16} className="text-accent" fill="currentColor" />
            <span className="font-display font-bold text-text">NEXUS</span>
          </div>
        </div>

        <div className="flex-1 p-6 lg:p-8 animate-fade-in">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
