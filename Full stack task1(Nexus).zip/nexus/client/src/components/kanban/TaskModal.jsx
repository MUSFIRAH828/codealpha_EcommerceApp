import { useState, useEffect } from 'react';
import { X, Calendar, Tag } from 'lucide-react';

const STATUSES = ['todo', 'in-progress', 'review', 'done'];
const PRIORITIES = ['low', 'medium', 'high', 'critical'];

export default function TaskModal({ task, onSave, onClose }) {
  const [form, setForm] = useState({
    title: '',
    description: '',
    status: 'todo',
    priority: 'medium',
    tags: '',
    dueDate: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (task) {
      setForm({
        title: task.title || '',
        description: task.description || '',
        status: task.status || 'todo',
        priority: task.priority || 'medium',
        tags: task.tags?.join(', ') || '',
        dueDate: task.dueDate ? task.dueDate.split('T')[0] : '',
      });
    }
  }, [task]);

  const handle = (e) => setForm(p => ({ ...p, [e.target.name]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.title.trim()) { setError('Title is required'); return; }
    setLoading(true);
    try {
      await onSave({
        ...form,
        tags: form.tags ? form.tags.split(',').map(t => t.trim()).filter(Boolean) : [],
      });
      onClose();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save task');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="card w-full max-w-lg animate-slide-up">
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="font-display font-semibold text-text text-lg">
            {task?._id ? 'Edit Task' : 'New Task'}
          </h2>
          <button onClick={onClose} className="text-muted hover:text-text transition-colors">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={submit} className="p-6 space-y-5">
          {error && (
            <div className="bg-rose/10 border border-rose/30 rounded-lg px-4 py-2.5 text-rose text-sm">{error}</div>
          )}

          <div>
            <label className="block text-sm font-medium text-dim mb-1.5 font-body">Title *</label>
            <input name="title" value={form.title} onChange={handle}
              placeholder="Task title…" className="input" />
          </div>

          <div>
            <label className="block text-sm font-medium text-dim mb-1.5 font-body">Description</label>
            <textarea name="description" value={form.description} onChange={handle}
              placeholder="Optional description…" rows={3}
              className="input resize-none" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-dim mb-1.5 font-body">Status</label>
              <select name="status" value={form.status} onChange={handle} className="input">
                {STATUSES.map(s => <option key={s} value={s}>{s.replace('-', ' ')}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-dim mb-1.5 font-body">Priority</label>
              <select name="priority" value={form.priority} onChange={handle} className="input">
                {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-dim mb-1.5 font-body flex items-center gap-1.5">
              <Tag size={14} /> Tags <span className="text-xs text-muted">(comma separated)</span>
            </label>
            <input name="tags" value={form.tags} onChange={handle}
              placeholder="design, backend, urgent" className="input" />
          </div>

          <div>
            <label className="block text-sm font-medium text-dim mb-1.5 font-body flex items-center gap-1.5">
              <Calendar size={14} /> Due Date
            </label>
            <input name="dueDate" type="date" value={form.dueDate} onChange={handle} className="input" />
          </div>

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-ghost flex-1">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 flex items-center justify-center gap-2">
              {loading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : null}
              {loading ? 'Saving…' : task?._id ? 'Update Task' : 'Create Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
