import { Calendar, Pencil, Trash2, Tag } from 'lucide-react';

const PRIORITY_COLORS = {
  low: 'tag-low',
  medium: 'tag-medium',
  high: 'tag-high',
  critical: 'tag-critical',
};

const PRIORITY_BAR = {
  low: 'bg-emerald',
  medium: 'bg-amber',
  high: 'bg-rose',
  critical: 'bg-rose',
};

export default function KanbanCard({ task, onEdit, onDelete }) {
  const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'done';

  return (
    <div className="bg-surface border border-border rounded-lg p-4 hover:border-accent/30 transition-all duration-200 group shadow-card relative overflow-hidden">
      {/* Priority indicator */}
      <div className={`absolute left-0 top-0 bottom-0 w-0.5 ${PRIORITY_BAR[task.priority]}`} />

      <div className="flex items-start justify-between gap-2 mb-2">
        <h3 className="font-body font-medium text-text text-sm leading-snug">{task.title}</h3>
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
          <button onClick={() => onEdit(task)}
            className="p-1 text-muted hover:text-accent transition-colors rounded">
            <Pencil size={13} />
          </button>
          <button onClick={() => onDelete(task._id)}
            className="p-1 text-muted hover:text-rose transition-colors rounded">
            <Trash2 size={13} />
          </button>
        </div>
      </div>

      {task.description && (
        <p className="text-xs text-muted font-body mb-3 line-clamp-2">{task.description}</p>
      )}

      {task.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-3">
          {task.tags.map(tag => (
            <span key={tag} className="text-xs bg-white/5 text-dim px-1.5 py-0.5 rounded font-mono">
              #{tag}
            </span>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between">
        <span className={`badge ${PRIORITY_COLORS[task.priority]}`}>{task.priority}</span>
        {task.dueDate && (
          <span className={`flex items-center gap-1 text-xs font-mono ${isOverdue ? 'text-rose' : 'text-muted'}`}>
            <Calendar size={11} />
            {new Date(task.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          </span>
        )}
      </div>
    </div>
  );
}
