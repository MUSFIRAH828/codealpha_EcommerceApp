/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Syne"', 'sans-serif'],
        body: ['"DM Sans"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        void: '#080B14',
        surface: '#0E1420',
        panel: '#141B2D',
        border: '#1E2A42',
        accent: '#5B8EFF',
        'accent-glow': '#3D6FE8',
        cyan: '#00D4FF',
        emerald: '#00E5A0',
        amber: '#FFB347',
        rose: '#FF5C7A',
        muted: '#4A5568',
        dim: '#8892A4',
        text: '#E2E8F4',
      },
      boxShadow: {
        glow: '0 0 20px rgba(91,142,255,0.25)',
        'glow-sm': '0 0 10px rgba(91,142,255,0.15)',
        card: '0 4px 24px rgba(0,0,0,0.4)',
      },
      backgroundImage: {
        'grid-pattern': 'linear-gradient(rgba(91,142,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(91,142,255,0.03) 1px, transparent 1px)',
      },
      backgroundSize: {
        'grid': '40px 40px',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-out',
        'slide-up': 'slideUp 0.4s ease-out',
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: { from: { opacity: 0 }, to: { opacity: 1 } },
        slideUp: { from: { opacity: 0, transform: 'translateY(16px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
        pulseGlow: { '0%,100%': { boxShadow: '0 0 10px rgba(91,142,255,0.2)' }, '50%': { boxShadow: '0 0 25px rgba(91,142,255,0.5)' } },
      },
    },
  },
  plugins: [],
}
